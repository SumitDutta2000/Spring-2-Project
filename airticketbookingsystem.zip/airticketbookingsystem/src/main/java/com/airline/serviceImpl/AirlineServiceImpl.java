package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;
import com.airline.repository.AirlineRepository;
import com.airline.repository.FlightRepository;
import com.airline.service.AirlineService;
import com.airline.util.AirlineConverter;
import com.airline.util.FlightConverter;
@Service
public class AirlineServiceImpl implements AirlineService {
	private static final Logger l = LoggerFactory.getLogger(AirlineService.class);
	
		@Autowired
		AirlineRepository airlineRepository;
		@Autowired
		AirlineConverter airlineConverter;
		//for create Airline in ServiceImpl
		@Override
		public AirlineDTO saveAirline(Airline airline) {
			
			Airline air=airlineRepository.save(airline);
			l.info("Airline "+airline.toString()+" added at "+new Date());
			return airlineConverter.convertToAirlineDTO(air);
			
	}
		//for update airline in ServiceImpl
		@Override
		public AirlineDTO updateAirline(int id, Airline airline) {
			//we need to check wheather Airline with given exist in DB or not
			Airline existAir=airlineRepository.findById(id).orElseThrow(()->
			new ResourceNotFoundException("Airline", "id", id));
			//we will get data from client and set in existing Airline
			existAir.setAirlineName(airline.getAirlineName());
			existAir.setFare(airline.getFare());
			
		airlineRepository.save(existAir);
		l.info("Updating airline details of "+id+" at "+new Date() );
		return airlineConverter.convertToAirlineDTO(existAir);
			
		}
		//for fetch airline by id in ServiceImpl
		@Override
		public AirlineDTO getAirlineById(int id) {
			Airline air=airlineRepository.findById(id).orElseThrow(()->
			new ResourceNotFoundException("Airline", "id", id));
			l.info("airline with "+id +" is fetched at " + new java.util.Date());
			return airlineConverter.convertToAirlineDTO(air);
			
		}
		//for fetch airline by name in ServiceImpl
		@Override
		public AirlineDTO getAirlineByName(String airlineName) {
			Airline air=airlineRepository.getAirlineByName(airlineName);
			l.info("Getting airline details using name "+ new Date());
			return airlineConverter.convertToAirlineDTO(air);
			
		}
		//for delete airline by id in ServiceImpl
		@Override
		public String deleteAirlineById(int id) {
			String msg=null;
			Optional<Airline> opPass=airlineRepository.findById(id);
			if(opPass.isPresent())
			{
				airlineRepository.deleteById(id);
				msg="record deleted successfully";
			}
			else {
				throw new ResourceNotFoundException("Airline", "id", id);
			}
			l.info("Deleting airline details of "+id+ " at " + new Date());
			return msg;
		}
		//method used to get all airline details present in the system
		@Override
		public List<AirlineDTO> getAllAirline() {
			List<Airline> airlines = airlineRepository.findAll();
			l.info("Fetching all airline details at "+ new Date() );
			List<AirlineDTO> airlinesDTO = new ArrayList<>();
			for(Airline air: airlines)
			{
				airlinesDTO.add(airlineConverter.convertToAirlineDTO(air));
			}
			return airlinesDTO;
		}

}
