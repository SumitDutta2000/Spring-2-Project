package com.airline.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.airline.entity.Admin;
import com.airline.entity.Passenger;
import com.airline.model.AdminDTO;
import com.airline.model.PassengerDTO;

@Component
public class Converter {
// for passenger converter
	//convert from PassengerDTO to Entity(Passenger)
	public Passenger covertToPassengerEntity(PassengerDTO passengerDTO)
	{
		Passenger passenger=new Passenger();
		if(passengerDTO!=null)
		{
			BeanUtils.copyProperties(passengerDTO, passenger);
		}
		return passenger;
	}
	
	
	//convert from passenger Entity to PassengerDTO
	public PassengerDTO convertToPassengerDTO(Passenger passenger)
	{
		PassengerDTO passengerDTO=new PassengerDTO();
		if(passenger!=null)
		{
			BeanUtils.copyProperties(passenger, passengerDTO);
		}
		return passengerDTO;
	}
	
	
	//For Admin Converter
	
	//convert from AdminDTO to Entity(Admin)
		public Admin covertToAdminEntity(AdminDTO adminDTO)
		{
			Admin admin=new Admin();
			if(adminDTO!=null)
			{
				BeanUtils.copyProperties(adminDTO, admin);
			}
			return admin;
		}
		
		
		//convert from admin Entity to adminDTO
		public AdminDTO convertToAdminDTO(Admin admin)
		{
			AdminDTO adminDTO=new AdminDTO();
			if(admin!=null)
			{
				BeanUtils.copyProperties(admin, adminDTO);
			}
			return adminDTO;
		}
}
