package com.airline.model;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.airline.entity.Flight;

import lombok.Data;


@Data
public class AirlineDTO {
	private int id;
	@NotNull(message = "airline name can not be null")
	private String airlineName;
	@NotNull(message = "fare can not be null")
	private float fare;

	List<Flight> flights;
}
