package com.airline.service;

import java.util.List;

import com.airline.entity.Airline;
import com.airline.entity.Passenger;
import com.airline.model.AirlineDTO;
import com.airline.model.PassengerDTO;



public interface AirlineService {
	AirlineDTO saveAirline(Airline airline);
	AirlineDTO updateAirline(int id,Airline airline);
	AirlineDTO getAirlineById(int id);
	AirlineDTO getAirlineByName(String airlineName);
	String deleteAirlineById(int id);
	 List<AirlineDTO> getAllAirline();
	

}
