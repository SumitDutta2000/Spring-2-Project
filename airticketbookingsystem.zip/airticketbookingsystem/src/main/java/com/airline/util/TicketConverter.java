package com.airline.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.airline.entity.Flight;
import com.airline.entity.TicketBooking;
import com.airline.model.FlightDTO;
import com.airline.model.TicketBookingDTO;
@Component
public class TicketConverter {
	
	//convert from ticketDTO to Entity(Flight)
		public TicketBooking convertToTicketEntity(TicketBookingDTO ticketDTO)
		{
			TicketBooking tk=new TicketBooking();
			if(ticketDTO!=null)
			{
				BeanUtils.copyProperties(ticketDTO, tk);
			}
			return tk;
		}
		
		
		//convert from ticket Entity to ticketDTO
		public TicketBookingDTO convertToTicketBookingDTO(TicketBooking  ticket)
		{
			TicketBookingDTO ticketDTO=new TicketBookingDTO();
			if(ticket!=null)
			{
				BeanUtils.copyProperties(ticket, ticketDTO);
			}
			return ticketDTO;
		}


}
