package com.airline.service;

import java.util.List;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;


public interface FlightService {
FlightDTO saveFlight(Flight flight);
FlightDTO assignFlightToAirline(int flightId,int airlineId);
List<FlightDTO> searchFlight(String source,String destination);
FlightDTO updateFlight(int id,Flight flight);
FlightDTO getFlightById(int id);
String deleteFlightById(int id);

}
