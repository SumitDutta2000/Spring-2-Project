package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Admin;
import com.airline.entity.Passenger;
import com.airline.model.AdminDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.AdminRepository;
import com.airline.util.Converter;
@SpringBootTest
public class AdminServiceTest {
	@Autowired
	private AdminService adminService;
	@Autowired
	private Converter converter;
	
	@MockBean
	private AdminRepository adminRepository;
	
//	@Test
//	void testSaveAdmin()
//	{
//		Admin admin = Admin.builder().adminName("chayan").email("chayan@gmail.com").
//				userName("admin").password("admin123").role("admin").build();
//		
//		Mockito.when(adminRepository.save(admin)).thenReturn(admin);
//		 AdminDTO aDTO = converter.convertToAdminDTO(admin);
//		 AdminDTO adto=adminService.createAdmin(admin);
//		assertEquals(adto.getAdminName(), admin.getAdminName());
//	}
//	@Test
//	void testGetAllAdmin()
//	{
//		Admin admin1 = Admin.builder().adminName("pallab").email("pal@gmail.com").
//				userName("pallab").password("pal123").role("admin").build();
//		Admin admin2 = Admin.builder().adminName("chandan").email("cha@gmail.com").
//				userName("chandan").password("c123").role("admin").build();
//		
//		List<Admin> list=new ArrayList<Admin>();
//		list.add(admin1);
//		list.add(admin2);
//		
//		Mockito.when(adminRepository.findAll()).thenReturn(list);
//		
//		List<AdminDTO> adto = adminService.getAllAdmin();
//		
//		List<Admin> ad= new ArrayList<Admin>();
//		adto.forEach(adDto->
//		{
//			ad.add(converter.covertToAdminEntity(adDto));
//		});
//		
//		assertThat(ad).isEqualTo(list);
//	}
//	@Test
//	void testDeleteAdmin()
//	{
//		Admin admin = Admin.builder().adminName("pallab").email("pal@gmail.com").
//				userName("pallab").password("pal123").role("admin").build();
//	Optional<Admin> opad=Optional.of(admin);
//	Mockito.when(adminRepository.findById(opad.get().getId())).thenReturn(opad);
//	assertThat(adminService.deleteAdminById(opad.get().getId())).isEqualTo("record deleted successfully");
//}
//	@Test
//	@DisplayName("Negetive test case")
//	void testNegetiveGetAdminById()
//	{
//		Admin admin = Admin.builder().adminName("pallab").email("pal@gmail.com").
//				userName("pallab").password("pal123").role("admin").build();
//		Optional<Admin>opad=Optional.of(admin);
//		Mockito.when(adminRepository.findById(admin.getId())).thenReturn(opad);
//		
//		AdminDTO pDto=converter.convertToAdminDTO(opad.get());
//		assertThat(adminService.getAdminById(opad.get().getId())).isEqualTo(pDto);
//	
//	}
	
//	@Test
//	void testUpdateAdmin()
//	{
//		Admin admin = Admin.builder().adminName("pallab").email("pal@gmail.com").
//				userName("pallab").password("pal123").role("admin").build();
//		Optional<Admin>opad=Optional.of(admin);
//		Mockito.when(adminRepository.findById(admin.getId())).thenReturn(opad);
//		Admin a=opad.get();
//		a.setAdminName("Pallab Rudra");
//		Mockito.when(adminRepository.save(a)).thenReturn(a);
//		AdminDTO aDto=converter.convertToAdminDTO(a);
//	AdminDTO dto=adminService.updateAdmin(admin.getId(), admin);
//	assertEquals(dto.getAdminName(),a.getAdminName());
//	}
}
